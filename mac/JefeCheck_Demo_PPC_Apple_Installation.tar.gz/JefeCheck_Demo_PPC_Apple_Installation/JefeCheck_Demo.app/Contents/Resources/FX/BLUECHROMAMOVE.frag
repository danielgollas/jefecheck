uniform sampler2DRect Top;
uniform sampler2DRect Bottom;
uniform float ShowMatte;
uniform float ShowClean;
uniform float Bias;
uniform float OffsetX;
uniform float OffsetY;
uniform float ScaleX;
uniform float ScaleY;

void main()
{	
		vec4 top=texture2DRect(Top,gl_TexCoord[1].st);		
		vec4 bottom=texture2DRect(Bottom,vec2((gl_TexCoord[0].s+OffsetX)/ScaleX,  (gl_TexCoord[0].t+OffsetY)/ScaleY));		
		float matte= top.b-max(top.r,top.g);
		vec4 clean=vec4(top.r,top.g,min(top.b,top.g),top.a);
		
		if(ShowClean==1.0)
		{
			
			gl_FragColor=clean;
		}
		else if(ShowMatte==1.0){
		gl_FragColor = vec4(matte);//mix(top,bottom,(1-top.b));
		}
		else
		{
			//gl_FragColor=mix(vec4(0,1,0,0),vec4(1,0,0,0),matte);
			/*if(matte<Bias)
			gl_FragColor=clean;
			else
			gl_FragColor=vec4(0,1,0,0);*/
			//bottom=vec4(0,1,0,0);
			vec4 cutBottom=vec4(bottom*matte);
			gl_FragColor=max(vec4(0),cutBottom)*Bias+max(vec4(0),clean);
			//gl_FragColor=mix(vec4(0,1,0,0),top,Bias-matte);
		}
}