uniform float Amount;
uniform sampler2DRect first;
uniform sampler2DRect second;
uniform float X;
uniform float Y;
uniform float Slope;
uniform float Smoothness;
void main()
{	
		/*if((gl_TexCoord[0].s>Slope*(gl_TexCoord[0].t-X)+Y))
			gl_FragColor=texture2DRect(first,gl_TexCoord[0].st);
		else
			gl_FragColor=texture2DRect(second,gl_TexCoord[1].st);*/
		
		
		gl_FragColor=mix(texture2DRect(first,gl_TexCoord[0].st),    texture2DRect(second,gl_TexCoord[1].st),           smoothstep(  0.0, 1.0,   ( ((gl_TexCoord[0].s-Slope*(gl_TexCoord[0].t-Y) -X )) / Smoothness/max(abs(Slope),1.0)  )       ));


		//float dist=gl_TexCoord[0].x
		
//gl_FragColor = mix(texture2DRect(first,gl_TexCoord[0].st),texture2DRect(second,gl_TexCoord[1].st),Amount);
}