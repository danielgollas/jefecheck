uniform sampler2DRect Source;
uniform sampler2DRect Matte;
uniform float Method;
uniform float Outside;
void main()
{	
	if(Method==3.0) //alpha==3
	{
		vec4 source=texture2DRect(Source,gl_TexCoord[0].st);		
		vec4 matte=texture2DRect(Matte,gl_TexCoord[1].st);		
		gl_FragColor =vec4(mix(vec4(0),source,abs(Outside-matte.a)));
	}
	else if(Method==0.0){ //R==0
		vec4 source=texture2DRect(Source,gl_TexCoord[0].st);		
		vec4 matte=texture2DRect(Matte,gl_TexCoord[1].st);		
		gl_FragColor =vec4(mix(source,vec4(0),(1.0-matte.r)));
	}
	else if(Method==1.0){ //G==1
		vec4 source=texture2DRect(Source,gl_TexCoord[0].st);		
		vec4 matte=texture2DRect(Matte,gl_TexCoord[1].st);		
		gl_FragColor =vec4(mix(source,vec4(0),(1.0-matte.g)));
	}
	else if(Method==2.0){ //B==2
		vec4 source=texture2DRect(Source,gl_TexCoord[0].st);		
		vec4 matte=texture2DRect(Matte,gl_TexCoord[1].st);		
		gl_FragColor =vec4(mix(source,vec4(0),(1.0-matte.b)));
	}
	else if(Method==3.0){ //Y==3
		vec4 source=texture2DRect(Source,gl_TexCoord[0].st);		
		vec4 matte=texture2DRect(Matte,gl_TexCoord[1].st);		
		//get luminance
		const vec3 lumCoeff = vec3(0.2125,0.7154,0.0721);
		float luminance=dot(matte.rgb,lumCoeff);
		gl_FragColor =vec4(mix(source,vec4(0),(1.0-luminance)));
	}
}