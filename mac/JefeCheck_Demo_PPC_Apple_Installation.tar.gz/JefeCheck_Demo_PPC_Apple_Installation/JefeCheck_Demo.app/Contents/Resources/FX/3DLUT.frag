uniform sampler2DRect image;
uniform sampler3D LUT;

void main()
{	
		vec4 cubeCoords=texture2DRect(image,gl_TexCoord[0].st)*(15.0/16.0) + 1.0 /32.0;		
		gl_FragColor = vec4(vec3(texture3D(LUT,cubeCoords.rgb).rgb),1);
}