#!/usr/bin/perl -wT

package untaintModule;

use strict;

our $EMAIL = 0;
our $TXNID = 1;
our $AMOUNT = 2;
our $QUANTITY = 3;
our $PCN = 4;
our $MAC = 5;
our $VERSION = 6;

sub untaint
{
   ( my $what, my $tainted ) = @_;

   if ( @_ != 2 ) {
      die "Invalid arguments passed to untaintModule::untaint\n";
   }

   my $untainted = "";


   if ( $what ==  $EMAIL ) {
      if ( $tainted =~ /(\S+)\@([\w.-]+)/ ) {
	 $untainted = "$1\@$2";
      }
   } elsif ( $what == $TXNID ) {
      if ( $tainted =~ /(^\w+$)/ ) {
	 $untainted = $1;
      }
   } elsif ( $what == $AMOUNT ) {
      if ( $tainted =~ /(^\d+\.?\d+$)/ ) {
	 $untainted = $1;
      }
   } elsif ( $what == $QUANTITY ) {
      if ( $tainted =~ /(^\d+$)/ ) {
	 $untainted = $1;
      }
   } elsif ( $what == $PCN ) {
      if ( $tainted =~ /(^[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}$)/ ) {
	 $untainted = $1;
      }
   } elsif ( $what == $MAC ) {
      if ( $tainted =~ /(^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$)/ ) {
	 $untainted = $1;
      }
   } elsif ( $what == $VERSION ) {
      if ( $tainted =~ /(^\d+\.\d+\.\d+$)/ ) {
	 $untainted = $1;
      }
   }
   if ( !$untainted ) {   
      $untainted = "";
      warn ("PARSING $what: TAINTED DATA SENT BY ENV{'REMOTE_ADDR'}: $tainted: $!" ); 
   }

   return $untainted;
}

1;
