#!/usr/bin/perl -w

package License;

use strict;

sub new 
{
   my $self = {};
   $self->{ID} = undef;
   $self->{CLIENT} = undef;
   $self->{REQUESTER} = undef;
   $self->{COMPANY} = undef;
   $self->{OS} = undef;
   $self->{VERSION} = undef;
   $self->{MAC} = undef;
   $self->{TEXT} = undef;
   $self->{DATE} = undef;
   $self->{IP} = undef;
   $self->{PURCHASEID} = undef;

   bless($self);
   return $self;
}

sub id 
{
   my $self = shift;
   if ( @_ ) {
      $self->{ID} = shift;
   }
   return $self->{ID};
}

sub client 
{
   my $self = shift;
   if ( @_ ) {
      $self->{CLIENT} = shift; 
   }
   return $self->{CLIENT};
}

sub requester 
{
   my $self = shift;
   if ( @_ ) {
      $self->{REQUESTER} = shift; 
   }
   return $self->{REQUESTER};
}

sub company 
{
   my $self = shift;
   if ( @_ ) {
      $self->{COMPANY} = shift; 
   }
   return $self->{COMPANY};
}

sub os
{
   my $self = shift;
   if ( @_ ) {
      $self->{OS} = shift; 
   }
   return $self->{OS};
}

sub version
{
   my $self = shift;
   if ( @_ ) {
      $self->{VERSION} = shift; 
   }
   return $self->{VERSION};
}

sub mac 
{
   my $self = shift;
   if ( @_ ) {
      $self->{MAC} = shift; 
   }
   return $self->{MAC};
}

sub text
{
   my $self = shift;
   if ( @_ ) {
      $self->{TEXT} = shift; 
   }
   return $self->{TEXT};
}

sub date
{
   my $self = shift;
   if ( @_ ) {
      $self->{DATE} = shift; 
   }
   return $self->{DATE};
}

sub ip
{
   my $self = shift;
   if ( @_ ) {
      $self->{IP} = shift;
   }
   return $self->{IP};
}

sub purchaseID
{
   my $self = shift;
   if ( @_ ) {
      $self->{PURCHASEID} = shift;
   }
   return $self->{PURCHASEID};
}




1;
