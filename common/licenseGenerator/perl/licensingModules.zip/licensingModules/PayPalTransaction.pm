#!/usr/bin/perl -w

package PayPalTransaction;

use strict;

sub new 
{
   my $self = {};
   $self->{ID} = undef;
   $self->{TXNID} = undef;
   $self->{AMOUNT} = undef;
   $self->{QUANTITY} = undef;
   $self->{PURCHASEID} = undef;
   $self->{DATE} = undef;
   $self->{PAYEREMAIL} = undef;
   $self->{USERREMAIL} = undef;
   $self->{CURRENCY} = undef;

   bless($self);

   return $self;
}

sub id 
{
   my $self = shift;
   if ( @_ ) {
      $self->{ID} = shift; 
   }
   return $self->{ID};
}

sub txnID 
{
   my $self = shift;
   if ( @_ ) {
      $self->{TXNID} = shift; 
   }
   return $self->{TXNID};
}

sub amount 
{
   my $self = shift;
   if ( @_ ) {
      $self->{AMOUNT} = shift; 
   }
   return $self->{AMOUNT};
}

sub quantity 
{
   my $self = shift;
   if ( @_ ) {
      $self->{QUANTITY} = shift; 
   }
   return $self->{QUANTITY};
}

sub purchaseID 
{
   my $self = shift;
   if ( @_ ) {
      $self->{PURCHASEID} = shift; 
   }
   return $self->{PURCHASEID};
}

sub date 
{
   my $self = shift;
   if ( @_ ) {
      $self->{DATE} = shift; 
   }
   return $self->{DATE};
}

sub payerEmail 
{
   my $self = shift;
   if ( @_ ) {
      $self->{PAYEREMAIL} = shift; 
   }
   return $self->{PAYEREMAIL};
}

sub userEmail 
{
   my $self = shift;
   if ( @_ ) {
      $self->{USEREMAIL} = shift; 
   }
   return $self->{USEREMAIL};
}

sub currency 
{
   my $self = shift;
   if ( @_ ) {
      $self->{CURRENCY} = shift; 
   }
   return $self->{CURRENCY};
}

1;
