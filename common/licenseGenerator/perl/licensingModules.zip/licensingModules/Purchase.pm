#!/usr/bin/perl -w

package Purchase;

use strict;

sub new 
{
   my $self = {};
   $self->{ID} = undef;
   $self->{DATE} = undef;
   $self->{QUANTITY} = undef;
   $self->{PCN} = undef;
   $self->{EMAIL} = undef;
   $self->{VERSION} = undef;
   $self->{STATUS} = undef;

   bless($self);
   return $self;
}

sub id 
{
   my $self = shift;
   if ( @_ ) {
      $self->{ID} = shift; 
   }
   return $self->{ID};
}

sub date 
{
   my $self = shift;
   if ( @_ ) {
      $self->{DATE} = shift; 
   }
   return $self->{DATE};
}

sub quantity 
{
   my $self = shift;
   if ( @_ ) {
      $self->{QUANTITY} = shift; 
   }
   return $self->{QUANTITY};
}

sub pcn 
{
   my $self = shift;
   if ( @_ ) {
      $self->{PCN} = shift; 
   }
   return $self->{PCN};
}

sub email 
{
   my $self = shift;
   if ( @_ ) {
      $self->{EMAIL} = shift; 
   }
   return $self->{EMAIL};
}

sub version 
{
   my $self = shift;
   if ( @_ ) {
      $self->{VERSION} = shift; 
   }
   return $self->{VERSION};
}

sub status 
{
   my $self = shift;
   if ( @_ ) {
      $self->{STATUS} = shift; 
   }
   return $self->{STATUS};
}

1;
