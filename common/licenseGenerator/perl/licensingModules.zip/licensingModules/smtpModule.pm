#!/usr/bin/perl -w
use strict;

package smtpModule;

use Net::SMTP;
use MIME::Base64;
use MIME::Lite;

#use lib "licensingModules";
use lib "/home/jefeco5/bin/licensingModules";

use Purchase;
use License;
use PayPalTransaction;

use enums;

my $mailServer = "mail.jefecorp.com";
my $activatorAddress = "activator\@jefecorp.com";
my $salesAddress = "sales\@jefecorp.com";

my $user = "activator+jefecorp.com";
my $pass = "truco10";


sub sendMail
{
   open F, ">smtpModLog.txt";
   (my $email, my $msg) = @_;

   if ( @_ != 2 or !$email or !$msg ) {
      print F "No message to send\n";
      close F;
      return -1;
   }
   my $smtp = Net::SMTP->new($mailServer, Timeout=> 60, Debug=>1,);

   $smtp->datasend("AUTH LOGIN\n");
   $smtp->response();

   $smtp->datasend(encode_base64($user));
   $smtp->response();

   $smtp->datasend(encode_base64($pass));
   $smtp->response();

   $smtp->mail($activatorAddress);
   $smtp->to($email);

   my $msgToString = $msg->as_string;
   $smtp->data();
   $smtp->datasend($msgToString);
   $smtp->dataend();
   $smtp->quit();
}

sub maskPCN
{
   open F, ">smtpModLog.txt";
   my $pcn = shift;

   if ( !$pcn ) {
      print F "Empty pcn\n";
      close F;
      return -1;
   }

   #Mask the purchase confirmation number:
   #i.e. if pcn = '1234-ABcD-0p2F-BDCA'
   #then pcn will be '****-****-****-BDCA'
   $pcn =~ s/\w(?=.{4})/*/g;

   return $pcn;
}

sub sendLicense
{
   open F, ">smtpModLog.txt";
   my ($licensesLeft, $license, $purchase, $exists ) = @_;

   if ( @_ != 4 or !$license or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendLicense";
      close F;
      return -1;
   }

   my $clientName = $license->client;
   my $requesterName = $license->requester;   
   my $os = $license->os;
   my $jefecheckVersion = $license->version;
   my $licenseText = $license->text;
   my $requesterIP = $license->ip;

   my $subject = "JefeCheck $jefecheckVersion License for $clientName ($os)\n";

   my $messageBody ="Dear customer,\n Attached is your requested license for JefeCheck $jefecheckVersion\n";

if ( $exists == 1 ) {
$messageBody .= "\nYou already have a license for this computer, so we're sending you the existing one\n";
}
   my $purchaseDate = $purchase->date;
   my $purchasedQuantity = $purchase->quantity;
   my $pcn = $purchase->pcn;
   my $email = $purchase->email;

   $pcn = maskPCN($pcn);

   $messageBody .= "Purchase confirmation number ends in: $pcn\n";
   $messageBody .= "Purchased on: $purchaseDate\n";
   $messageBody .= "Requested by : $requesterName (from ip: $requesterIP)\n";
   $messageBody .= "For: $os\n";
   $messageBody .= "\nYou have: $licensesLeft licenses left (out of $purchasedQuantity purchased)\n";
   $messageBody .= "\nThanks for your purchase!\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n"; 

   my $msg = MIME::Lite->new( From=>$activatorAddress,
      To=>$email,
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";

   my $attachmentName = "$clientName\_$os\_jefecheck\_$jefecheckVersion.lic";

   $msg->attach( Type=>'text/plain', 
      Filename=>$attachmentName, 
      Data=>$licenseText, 
      Disposition=>'attachment') or die "Error adding attachment: $!\n";

   sendMail($email, $msg);
}

sub sendBuyMoreLicenses
{
   open F, ">smtpModLog.txt";
   my ($license, $purchase) = @_;
   if ( @_ != 2 or !$license or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendBuyMoreLicenses";
      close F;
      return -1;
   }

   my $clientName = $license->client;
   my $os = $license->os;
   my $jefecheckVersion = $license->version;
   my $licenseText = $license->text;
   my $requesterIP = $license->ip;

   my $purchaseDate = $purchase->date;
   my $purchasedQuantity = $purchase->quantity;
   my $pcn = $purchase->pcn;
   my $email = $purchase->email;

   my $subject = "JefeCheck Licensing\n";

   my $messageBody ="Dear customer, \nWe recieved the following request for a JefeCheck license:\n";

   $pcn = maskPCN($pcn);

   $messageBody .= "Purchase confirmation number ends in: $pcn\n";
   $messageBody .= "Purchased on: $purchaseDate\n";
   $messageBody .= "Requested by: $requesterIP\n";
   $messageBody .= "For: $os\n";
   $messageBody .= "JefeCheck Version: $jefecheckVersion\n";

   $messageBody .= "\nUnfortunately you have used up all your licenses, you can always purchase more at: http://jefecheck.jefecorp.com/purchase.html\n";
   $messageBody .= "\nThank you!\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n"; 

   my $msg = MIME::Lite->new( From=>$activatorAddress,
      To=>$email,   
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";

   sendMail($email, $msg);
}

sub sendBuyUpgrade
{
   open F, ">smtpModLog.txt";
   my ( $requestedVersion, $license, $purchase) = @_;
   if ( @_ != 3 or !$requestedVersion or !$license or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendBuyUpgrade";
      close F;
      return -1;
   }
   my $clientName = $license->client;
   my $os = $license->os;
   my $jefecheckVersion = $license->version;
   my $licenseText = $license->text;
   my $requesterIP = $license->ip;

   my $purchaseDate = $purchase->date;
   my $purchasedQuantity = $purchase->quantity;
   my $pcn = $purchase->pcn;
   my $email = $purchase->email;

   my $subject = "JefeCheck Licensing\n";

   my $messageBody ="Dear customer,\nWe recieved the following request for a JefeCheck license:\n";

   $pcn = maskPCN($pcn);

   $messageBody .= "Purchase confirmation number ends in: $pcn\n";
   $messageBody .= "Purchased on: $purchaseDate\n";
   $messageBody .= "Requested by: $requesterIP\n";
   $messageBody .= "For: $os\n";
   $messageBody .= "Requested JefeCheck Version: $requestedVersion\n";
   $messageBody .= "Purchased Version: $jefecheckVersion\n";

   $messageBody .= "\nUnfortunately the version you purchased is older than the one you requested, but you can always buy an upgrade at: http://jefecheck.jefecorp.com/purchase.html\n";
   $messageBody .= "\nThank you!\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n"; 

   my $msg = MIME::Lite->new( From=>$activatorAddress,
      To=>$email,   
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";
   sendMail($email, $msg);
}

sub sendPurchaseConfirmation
{
   open F, ">smtpModLog.txt";
   my ($purchase, $ppTransaction) = @_;
   if ( @_ != 2 or !$ppTransaction or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendPurchaseConfirmation";
      close F;
      return -1;
   }

   my $quantity = $purchase->quantity;
   my $pcn = $purchase->pcn;
   my $version = $purchase->version;
   my $purchaseDate = $purchase->date;

   my $amount = $ppTransaction->amount;
   my $currency = $ppTransaction->currency;
   my $paymentDate = $ppTransaction->date;
   my $payerEmail = $ppTransaction->payerEmail;
   my $userEmail = $ppTransaction->userEmail;
   my $txnID = $ppTransaction->txnID;

   my $subject = "JefeCheck Licensing - Payment Received\n";

   my $messageBody;

   if ( $quantity > 1 ) {
      $messageBody ="Dear customer,\nWe recieved your payment for $quantity JefeCheck licenses:\n";
   }
   else
   {
      $messageBody ="Dear customer,\nWe recieved your payment for a JefeCheck license:\n";
   }

   $messageBody .= "\nJefeCheck Version: $version\n";
   $messageBody .= "Number of licenses purchased: $quantity \n";
   $messageBody .= "Purchased on: $purchaseDate\n";
   $messageBody .= "For: $userEmail (needed for activation)\n";

   $messageBody .= "\nPayment details: \n-----------------\n";
   $messageBody .= "PayPal transaction ID: $txnID\n";
   $messageBody .= "Amount payed: $amount $currency\n";
   $messageBody .= "Payed by: $payerEmail\n";
   $messageBody .= "Payment date: $paymentDate\n";

   $messageBody .= "\nPurchase Confirmation Number: $pcn\n";
   $messageBody .= "Keep this number safe and secret or others could use it to activate JefeCheck with your purchases!\n";
   $messageBody .= "\nYou will use this number and the email address you registered during purchase for two things:\n";
   $messageBody .= "\n\t1) Download the JefeCheck installation program\n";
   $messageBody .= "\n\t2) Create a License from your computer once you've installed JefeCheck\n";

   $messageBody .= "\nTo download JefeCheck please visit: http://jefecheck.jefecorp.com/downloadForm.html\n"; 

   $messageBody .= "\nThanks for your purchase!\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n"; 

   my $msg = MIME::Lite->new( From=>$salesAddress,
      To=>$payerEmail,   
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->add(To=>$userEmail);
   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";

   sendMail($payerEmail, $msg);
   sendMail($userEmail, $msg);
}

sub sendNotifyInvalidAmount
{
   open F, ">smtpModLog.txt";
   my ($purchase, $ppTransaction) = @_;
   if ( @_ != 2 or !$ppTransaction or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendNotifyInvalidAmount\n";
      close F;
      return -1;
   }

   my $payerEmail = $ppTransaction->payerEmail;
   my $userEmail = $ppTransaction->userEmail;

   my $messageBody;
   my $version = $purchase->version;
   my $quantity = $purchase->quantity;

   if ( $quantity > 1 ) {
      $messageBody ="Dear customer,\nWe recieved your payment for $quantity JefeCheck licenses:\n";
   }
   else
   {
      $messageBody ="Dear customer,\nWe recieved your payment for a JefeCheck license:\n";
   }

   my $cost = dbModule::getCost($version, $quantity);

   print F "Cost: $cost\n";

   $messageBody .= "\nJefeCheck Version: $version\n";
   $messageBody .= "Number of licenses: $quantity\n";
   $messageBody .= "Purchased on: ".$purchase->date."\n";
   $messageBody .= "Cost: $cost USD\n";

   $messageBody .= "\nPayPal Transaction details: \n";
   $messageBody .= "Payment date: ".$ppTransaction->date."\n";
   $messageBody .= "Transaction ID: ".$ppTransaction->txnID."\n";
   $messageBody .= "Amount payed: ".$ppTransaction->amount."\n";

   print F "Messagebody: $messageBody\n";

   my $purchaseStatus = $purchase->status;
   if ( $purchaseStatus == $enums::PURCHASE_UNDERPAID ) {
      $messageBody .= "\nUnfortunately the amount was not enough for the products you requested, we will refund to your PayPal account in the next few days\n";
      $messageBody .= "\nFeel free to direct any questions regarding the refund to $salesAddress\n";
   } elsif ( $purchaseStatus == $enums::PURCHASE_OVERPAID ) {
      my $diff = $ppTransaction->amount - $cost;
      $messageBody .= "\nIt seems that you overpaid for the products you intended to purchase, we will proceed to refund you $diff to your PayPal Account\n";
   } elsif ( $purchaseStatus == $enums::PURCHASE_INVALID_CURRENCY ) {
      $messageBody .= "\nUnfortunately you used a non-supported currency when we only accept transactions in US Dollars, we will proceed to refund to your PayPal account in the next few days\n";
   }
   $messageBody .= "\nThank you for your business\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n";

   my $subject = "JefeCheck Purchase\n";

   my $msg = MIME::Lite->new( From=>$salesAddress,
      To=>$payerEmail,   
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->add(To=>$userEmail);
   $msg->add(To=>$salesAddress);
   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";

   sendMail($payerEmail, $msg);
   sendMail($userEmail, $msg);
}

sub sendNotifyNoSuchProduct
{
   open F, ">smtpModLog.txt";
   my ($purchase, $ppTransaction) = @_;
   if ( @_ != 2 or !$ppTransaction or !$purchase ) {
      print F "Error: Invalid argument size in smtpModule::sendNotifyNoSuchProduct\n";
      close F;
      return -1;
   }

   my $messageBody;
   my $version = $purchase->version;
   my $quantity = $purchase->quantity;

   my $payerEmail = $ppTransaction->payerEmail;
   my $userEmail = $ppTransaction->userEmail;

   $messageBody ="Dear customer,\nWe recieved payment for a non existent product:\n";

   $messageBody .= "\nPayPal Transaction details: \n";
   $messageBody .= "Payment date: ".$ppTransaction->date."\n";
   $messageBody .= "Transaction ID: ".$ppTransaction->txnID."\n";
   $messageBody .= "Amount payed: ".$ppTransaction->amount."\n";

   print F "Messagebody: $messageBody\n";

   $messageBody .= "As this is a mistake, we will refund to your account in the next few days\n";
   $messageBody .= "\nFeel free to direct any questions regarding the refund to $salesAddress\n";

   $messageBody .= "\nThank you for your business\n";
   $messageBody .= "\nGreetings from the JefeCheck team\n";

   my $subject = "JefeCheck Purchase\n";

   my $msg = MIME::Lite->new( From=>$salesAddress,
      To=>$payerEmail,   
      Subject=>$subject,
      Type=>'multipart/mixed') or die "Error: creating multipart container for email: $!\n";

   $msg->add(To=>$userEmail);
   $msg->add(To=>$salesAddress);
   $msg->attach( Type=>'TEXT', Data=>$messageBody) or die "Error: adding the message part to the mail: $!\n";

   sendMail($payerEmail, $msg);
   sendMail($userEmail, $msg);
}


1;
