#!/usr/bin/perl -w

use strict;
package licenseModule;

use lib "/home/juan/Projects/licenseGenerator/licensingModules";
#use lib "licensingModules";

use enums;
use cryptModule;

use MIME::Base64;

open F, ">licenseModLog.txt";

sub generateLicense 
{
   my %parameters = @_;

   if ( keys(%parameters) != $enums::PARAMS_SIZE ) {
      print F "Error: Incorrect number of args passed to licenseModule::generateLicense\n";
   close F;
   return -1;
   }

   my $ltext = "JefeCheck License\n";

   my $version = $parameters{'jefecheckversion'};
   my $companyName = $parameters{'companyname'};
   my $userName = $parameters{'clientname'};
   my $requesterName = $parameters{'requestername'}; 
   my $os = $parameters{'os'};
   my $mac = $parameters{'mac'};
   my $creationDate = localtime();
   my $ip = $parameters{'requesterip'};
   
   $ltext .= "JefeCheckVersion=$version\n";
   $ltext .= "CompanyName=$companyName\n";
   $ltext .= "ClientName=$userName\n";
   $ltext .= "OS=$os\n";
   $ltext .= "CreationDate=$creationDate\n";

   #The serial number
   my $serial = cryptModule::getRandomSequence($enums::SERIAL_SIZE);
   $ltext .= "Serial=$serial\n";
   my $msg = $version.$companyName.$userName.$os.$creationDate.$serial.$mac;
   my $activationNumber = encode_base64(cryptModule::getSHA1($msg));
   $ltext .= "ActivationNumber=$activationNumber";
  
   my $signed = cryptModule::signText($ltext);
   $ltext .= "\nSIGNATURE\n$signed";

   my $license = License->new;

   $license->id(0);
   $license->client($userName);
   $license->requester($requesterName);
   $license->company($companyName);
   $license->os($os);
   $license->version($version);
   $license->mac($mac);
   $license->date($creationDate);
   $license->ip($ip);
   $license->text($ltext);

   return $license;
}

1;
