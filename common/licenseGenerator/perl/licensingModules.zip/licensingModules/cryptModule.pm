#!/usr/bin/perl -w
use strict;

package cryptModule;

use Crypt::OpenSSL::DSA;
use Crypt::OpenSSL::RSA;
use Crypt::CBC;

open F, ">cryptModLog.txt";

sub getSHA1($)
{
   my $message = shift;

   my $sha1 = Digest::SHA1->new;
   $sha1->add($message);
   my $digest = $sha1->digest;
   return $digest;
}

sub getRandomSequence
{
   (my $size, my $blockSize, my $delim) = @_;

   if ( @_ > 3 or @_ < 1 ) {
      print F "Error: Incorrect number of args in cryptModule::getRandomSequence\n";
      close F;
      return -1;
   }

   if ( !$blockSize ) {
      $blockSize = 1; 
   }
   if ( !$delim ) {
      $delim = "";
   }

   if ( $blockSize > $size ) {
      $blockSize = $size;
   }

   my $str;
   my @charmap = ('0'..'9', 'A'..'Z');

   $str = join '', map $charmap[rand @charmap], 0..$size-1;

   $str =~ s/\w{$blockSize}(?=\w)/$&$delim/g;

   return $str;
}

sub slurpFile($){
   my ($filename) = @_;
   local( $/, *FH ) ;
   open( FH, $filename ) or die $!;
   my $text = <FH>;
   close FH;
   return $text;
}

sub preparePassphrase($)
{
   my ($key) = @_;

   if(length($key)<56)
   {
      $key.='0' x (56-length($key));
   }
   else
   {
      $key=substr($key,0,56);
   }
   return $key;
}

sub encryptBlowfish
{
   my %param=@_;

   if ( keys(%param) != 2 ) {
      print F "Error: Incorrect number of arguments in cryptModule::encryptBlowfish\n";
      close F;
      return -1;
   }
   my $key=$param{'passphrase'};
   my $message=$param{'message'};

   my $iv = "12345678";

   $key=preparePassphrase($key);
   my $cipher = Crypt::CBC->new(-literal_key => 1,
      -cipher	 => 'Blowfish',
      -key         => $key,
      -iv          => $iv,
      -header      => 'none',
      -padding     => "null",);

   my $ciphertext = $cipher->encrypt_hex($message.chr(0));
   return $ciphertext;
}

sub decryptBlowfish
{
#NOTE: passphrase must be 56 characters in lenght
   my %param=@_;

   if ( keys(%param) != 2 ) {
      print F "Error: Incorrect number of arguments in cryptModule::decryptBlowfish\n";
      close F;
      return -1;
   }

   my $key=$param{'passphrase'};
   my $message=$param{'message'};

   $key=preparePassphrase($key);


   my $iv = "12345678";

   my $cipher = Crypt::CBC->new(-literal_key => 1,
      -cipher	 => 'Blowfish',
      -key         => $key,
      -iv          => $iv,
      -header      => 'none',
      -padding     => "null",);


   my $cleartext= $cipher->decrypt_hex($message);
   return $cleartext;
}

sub signText($){
   #my %param=@_;
   #my $message=$param{'message'};
   my $message = shift;
   my $signature;

   my $filenameRSAPriv= "/home/jefeco5/bin/licensingModules/rsaKeys/privkey.pem";


   my $privKeyString=slurpFile($filenameRSAPriv);
   #print "\n".$privKeyString."\n";
   use MIME::Base64;
   use Digest::SHA1;

   #my $sha1 = Digest::SHA1->new;
   #$sha1->add($message);
   #my $myDigest = $sha1->digest;
   #print "\nmyDigest:".encode_base64($myDigest);
   my $rsa_priv = Crypt::OpenSSL::RSA->new_private_key($privKeyString );
   #my $sig      = $rsa_priv->sign($myDigest);
   my $sig      = $rsa_priv->sign($message);
#print "\nsigRSA: ".encode_base64($sig)."\n";
   return encode_base64($sig);
}

#  #DSA KEY GENERATION, WILL ONLY DO THIS ONCE AND INCLUDE THE PUBLIC KEY IN THE BINARY
# # generate keys and write out to PEM files
#   my $dsa = Crypt::OpenSSL::DSA->generate_parameters( 1024 );
#   $dsa->generate_key;
#   $dsa->write_pub_key( $filenameDSAPub );
#   $dsa->write_priv_key( $filenameDSAPriv );


#my $testString="C455D20B6C3FC4CF368BA38B669F095D821049859D63DEAD68C7467EDED9B9A0";
#my $testKey='lapingaloca';
#print "testString: $testString\n";
#print "Testkey: $testKey\n";
#print "testString clear:".decryptBlowfish(message => $testString, passphrase => $testKey)."\n";


#TEST RSA SIGNING SOME TEXT WITH A GENERATED KEY
#my $testMessageToSign="Esta es una cadena que vamos a firmar y es muy larga, probablemente falle si no le hacemos hash";
#my $testMessageSignature=signText($testMessageToSign);
#print "\nmessage: $testMessageToSign\nsignature:\n$testMessageSignature\n";
# OO style


#   open OUTSIG, ">>/home/dgollas/projects/perlLicenseGenerator/sigfile.b64" or die $!;
#   print OUTSIG encode_base64($sig);
#   close OUTSIG;
#   
#   #VERIFY THE SIGNATURE
#   print "Verifying sig with pub key: ".$filenameRSAPub."\n";
#   my $rsa_pub  = Crypt::OpenSSL::RSA->new_public_key( $pubKeyString );
#   my $valid    = $rsa_pub->verify($myDigest, $sig);
#   print "Valid: ".$valid."\n";

#exit(0);




#  #TEST SIGNING SOME TEXT WITH A GENERATED KEY
#   
#   #my $filenameDSAPriv="/home/dgollas/projects/perlLicenseGenerator/licenseSignDSA_private.pem";
#   #my $filenameDSAPub="/home/dgollas/projects/perlLicenseGenerator/licenseSignDSA_public.pem";
#   print "\n\nTesting DSA - SHA1 Signature\n";
#   my $filenameDSAPriv="/home/dgollas/projects/perlLicenseGenerator/opensslkeys/privkey.pem";
#   my $filenameDSAPub="/home/dgollas/projects/perlLicenseGenerator/opensslkeys/pubkey.pem";
#   
#  my $testMessageToSign="Esta es una cadena que vamos a firmar y es muy larga, probablemente falle si no le hacemos hash";
#  
#  # OO style
#  use MIME::Base64;
#  use Digest::SHA1;
# 
#  my $sha1 = Digest::SHA1->new;
#  $sha1->add($testMessageToSign);
#  my $myDigest = $sha1->digest;
#   
#   print "\nmyDigest:".encode_base64($myDigest);
#   my $dsa_priv = Crypt::OpenSSL::DSA->read_priv_key( $filenameDSAPriv );
#   my $sig      = $dsa_priv->sign($myDigest);
#   print "\nsig: ".encode_base64($sig)."\n";
#    
#   #VERIFY THE SIGNATURE
#   print "Verifying sig with pub key: ".$filenameDSAPub."\n";
#   my $dsa_pub  = Crypt::OpenSSL::DSA->read_pub_key( $filenameDSAPub );
#   my $valid    = $dsa_pub->verify($myDigest, $sig);
#   print "Valid: ".$valid."\n";
#   
#   

1;
