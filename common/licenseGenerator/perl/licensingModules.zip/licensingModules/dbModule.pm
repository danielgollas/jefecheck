#!/usr/bin/perl -w
use strict;

package dbModule;

#use lib "licensingModules";
use lib "/home/jefeco5/bin/licensingModules";

use License;
use Purchase;
use PayPalTransaction;
use DBI;
use DBD::mysql;
use cryptModule;
use enums;

my $host = "localhost";
my $port = 3306;
my $db = "jefeco5_jefechecklicensing";
#my $db = "jefechecklicensing";
my $dsn = "DBI:mysql:database=$db;host=$host";
my $licenseTable = "license";
my $purchaseTable = "purchase";
my $purchaseStatusTable = "purchasestatus";
my $downloadTable = "download";
my $ppTable = "paypaltransaction";
my $rateTable = "rate";
my $user = "jefeco5_licuser";
my $password = "rrQs2,(~UEQd";

open F, ">dbModLog.txt";

sub connectToDB
{
   return DBI->connect($dsn, $user, $password, {'RaiseError'=>1});
}

sub checkForExistingUser
{
   if ( @_ != 2) {
      print F "Error: Incorrect number of arguments in dmModule::checkForExistingUser\n";
      close F;
      return -1;
   }

   (my $email, my $pcn) = @_;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   my $query = $dbh->prepare("SELECT * FROM $purchaseTable WHERE purchaseconfirmation='$pcn' AND email='$email' AND ( status='ok' OR status='overpaid') ");  

   $query->execute();
   my $numberOfRows = $query->rows; 
   $query->finish();

   if ( $numberOfRows > 0 ) {
      return $numberOfRows; 
   }
   else {
      return -1;
   }
}

sub checkForExistingLicense
{
   if ( @_ != 4) {
      print F "Error: Incorrect number of arguments in dbModule::checkForExistingLicense\n";
      close F;
      return -1;
   }
   (my $pcn, my $macAddress, my $os, my $version) = @_;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   $version =~ /(\d+\.\d+)/;
   my $versionAbbrev = $1;

   my $query = $dbh->prepare("SELECT * FROM $licenseTable, $purchaseTable WHERE $licenseTable.purchaseid=$purchaseTable.purchaseid AND $purchaseTable.purchaseconfirmation='$pcn' AND $licenseTable.macaddress='$macAddress' AND $licenseTable.os='$os' AND $licenseTable.jefecheckversion >='$versionAbbrev'");  

   $query->execute();

   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $ref = $query->fetchrow_hashref();
      my $licenseID = $ref->{'licenseid'};
      $query->finish();
      return $licenseID;
   }
   else {
      $query->finish();
      $dbh->disconnect();
      return -1;
   }
}

sub getLicense
{
   if ( @_ != 2 ) {
      print F "Error: Incorrect number of arguments in dmModule::getLicense\n";
      close F;
      return -1;
   }
   (my $licenseID, my $pcn ) = @_;

   my $license = License->new;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   my $query = $dbh->prepare("SELECT * FROM $licenseTable, $purchaseTable WHERE $licenseTable.licenseid=$licenseID AND $licenseTable.purchaseid=$purchaseTable.purchaseid AND $purchaseTable.purchaseconfirmation='$pcn'");  

   $query->execute();

   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $tmp = $query->fetchrow_hashref();
      $query->finish();
      $dbh->disconnect();

      $license->id($tmp->{'licenseid'});
      $license->client($tmp->{'username'});
      $license->requester($tmp->{'requestername'});
      $license->company($tmp->{'companyname'});
      $license->os($tmp->{'os'});
      $license->version($tmp->{'jefecheckversion'});
      $license->mac($tmp->{'macaddress'});
      $license->text($tmp->{'licensetext'});
      $license->date($tmp->{'creationdate'});
      $license->ip($tmp->{'requesterip'});
      $license->purchaseID($tmp->{'purchaseid'});
   }

   return $license;
}

sub getPurchaseEmail
{
   if ( @_ != 1) {
      print F "Error: Incorrect number of arguments in dmModule::getPurchaseEmail\n";
      close F;
      return -1;
   }
   my ($purchaseID) = @_;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   my $query = $dbh->prepare("SELECT * FROM $purchaseTable WHERE purchaseid=$purchaseID");  

   $query->execute();

   my $email;
   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $ref = $query->fetchrow_hashref();
      $email = $ref->{'email'};
   }
   $query->finish();
   $dbh->disconnect();

   return $email;
}

sub getPurchase
{
   if ( @_ != 1 ) { 
      print F "Error: Incorrect number of arguments in dmModule::getPurchase\n";
      close F;
      return -1;
   }

   my ($purchaseID) = @_;
   my $purchase = Purchase->new;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";
   my $query = $dbh->prepare("SELECT * FROM $purchaseTable WHERE purchaseid=$purchaseID");  
   $query->execute();

   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $tmp = $query->fetchrow_hashref();
      $purchase->id($tmp->{'purchaseid'});
      $purchase->date($tmp->{'purchasedate'});
      $purchase->quantity($tmp->{'purchasedquantity'});
      $purchase->pcn($tmp->{'purchaseconfirmation'});
      $purchase->email($tmp->{'email'});
      $purchase->version($tmp->{'jefecheckversion'});
      #$purchase->status($tmp->{'status'});
      if ( lc($tmp->{'status'}) eq 'ok' ) {
	 $purchase->status($enums::PURCHASE_OK);
      } elsif ( lc($tmp->{'status'}) eq 'underpaid' ) {
	 $purchase->status($enums::PURCHASE_UNDERPAID);
      } elsif ( lc($tmp->{'status'}) eq 'overpaid' ) {
	 $purchase->status($enums::PURCHASE_OVERPAID);
      } elsif ( lc($tmp->{'status'}) eq 'nosuchproduct' ) {
	 $purchase->status($enums::PURCHASE_NOSUCHPRODUCT);
      }
   }
   $query->finish();
   $dbh->disconnect();

   return $purchase;
}

sub getPurchaseFromPCN
{
   if ( @_ != 1 ) { 
      print F "Error: Incorrect number of arguments in dmModule::getPurchaseFromPCN\n";
      close F;
      return -1;
   }

   my ($pcn) = @_;
   my $purchase = Purchase->new;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";
   my $query = $dbh->prepare("SELECT * FROM $purchaseTable WHERE purchaseconfirmation='$pcn'");  
   $query->execute();

   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $tmp = $query->fetchrow_hashref();
      $purchase->id($tmp->{'purchaseid'});
      $purchase->date($tmp->{'purchasedate'});
      $purchase->quantity($tmp->{'purchasedquantity'});
      $purchase->pcn($tmp->{'purchaseconfirmation'});
      $purchase->email($tmp->{'email'});
      $purchase->version($tmp->{'jefecheckversion'});
      #$purchase->status($tmp->{'status'});
      if ( lc($tmp->{'status'}) eq 'ok' ) {
	 $purchase->status($enums::PURCHASE_OK);
      } elsif ( lc($tmp->{'status'}) eq 'underpaid' ) {
	 $purchase->status($enums::PURCHASE_UNDERPAID);
      } elsif ( lc($tmp->{'status'}) eq 'overpaid' ) {
	 $purchase->status($enums::PURCHASE_OVERPAID);
      } elsif ( lc($tmp->{'status'}) eq 'nosuchproduct' ) {
	 $purchase->status($enums::PURCHASE_NOSUCHPRODUCT);
      }
   }
   $query->finish();
   $dbh->disconnect();

   return $purchase;
}

sub getNumberOfLicensesLeft
{
   if ( @_ != 1 ) { 
      print F "Error: Incorrect number of arguments in dmModule::getNumberOfLicensesLeft\n";
      close F;
      return -1;
   }

   my $purchasedquantity;
   my $pcn = shift;

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";
   my $query = $dbh->prepare("SELECT * FROM $licenseTable, $purchaseTable WHERE $licenseTable.purchaseid=$purchaseTable.purchaseID AND $purchaseTable.purchaseconfirmation='$pcn'");  

   $query->execute();
   my $numberOfRows = $query->rows;

   if ( $numberOfRows > 0 ) {
      my $ref = $query->fetchrow_hashref();
      $purchasedquantity = $ref->{'purchasedquantity'}; 
   }

   $query->finish();
   $dbh->disconnect();

   my $licensesLeft =  $purchasedquantity - $numberOfRows;

   if ( $licensesLeft < 0 ) {
      $licensesLeft = 0;
   }

   return $licensesLeft;
}


sub insertLicense
{
   ( my $pcn, my $license ) = @_;

   if ( !$pcn or !$license ) {
      print F "Error: Incorrect number of args passed to dbModule::insertLicense\n";
      close F;
   }

   my $dbh = connectToDB or die "Error: Could not establish connection to DB!\n";

   my $userName = $license->client;
   my $requesterName = $license->requester;
   my $companyName = $license->company;
   my $os = $license->os;
   my $jefecheckVersion = $license->version;
   my $mac = $license->mac;
   my $ip = $license->ip;
   my $creationDate = $license->date;
   my $licenseText = $license->text;

   $jefecheckVersion =~/(\d+\.*\d*)/;

   my $versionAbbrev = $1;

   print F "Select is: SELECT * FROM $purchaseTable WHERE purchaseconfirmation='$pcn' AND jefecheckversion >= '$versionAbbrev')\n";
   close F;

   #Get the purchaseID from the purchase table
   my $query = $dbh->prepare("SELECT * FROM $purchaseTable WHERE purchaseconfirmation='$pcn' AND jefecheckversion >= '$versionAbbrev' AND ( status='ok' OR status='overpaid' ) ");
   $query->execute();

   my $pid;
   my $numberOfRows = $query->rows;

   my $ref;
   my $versionInDB;

   if ( $numberOfRows > 0 ) {
      $ref = $query->fetchrow_hashref();
      $versionInDB = $ref->{'jefecheckversion'};
      $pid = $ref->{'purchaseid'};
      $license->purchaseID($pid);
      my $purchasedVersion = $ref->{'jefecheckversion'};
   }
   else {
      $query->finish();
      if ( $versionAbbrev > $versionInDB ) {    
	 print F "Version in database is older than the one requested\n";
	 close F;
	 return -1;
      }
      else {
	 print F "No such purchase\n";
	 close F;
	 return -2;
      }
   }
   $query->finish();

   my $insert = "INSERT INTO $licenseTable VALUES (0, '$userName',  '$requesterName', 
   '$companyName', '$os', '$jefecheckVersion', '$mac', '$licenseText', '$creationDate', '$ip', '$pid')";

   $dbh->do($insert);

   my $licenseID = $dbh->{'mysql_insertid'};
   $dbh->disconnect();

   return $licenseID;
}

sub checkForExistingTXNID
{
   my $txnID = shift;

   if ( !$txnID ) { 
      print F "Invalid TXNID passed to dbModule::checkForTXNID\n";
      close F;
      return -1;
   }

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB: $!\n";

   my $query = $dbh->prepare("SELECT * FROM $ppTable WHERE transactionid='$txnID'");  

   $query->execute();
   my $numberOfRows = $query->rows; 
   my $tableTXNID;
   my $ref;
   if ( $numberOfRows > 0 ) {
      $ref = $query->fetchrow_hashref();
      $tableTXNID = $ref->{'transactionid'};
      $query->finish();
      $dbh->disconnect();
      return $tableTXNID;
   }
   else {
      $query->finish();
      $dbh->disconnect();
      return -1;
   }
}

sub checkForValidAmount
{
   ( my $currency, my $quantity, my $paymentAmount, my $version ) = @_;

   if ( !$quantity or !$paymentAmount or !$version ) {
      print F "Incorrect number of args passed to dbModule::checkForValidAmount\n";
      close F;
      return -1;
   }

   if ( lc($currency) ne "usd" ) {
      return $enums::PURCHASE_INVALIDCURRENCY;
   }

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   my $query = $dbh->prepare("SELECT * FROM $rateTable WHERE jefecheckversion='$version' AND quantityfrom <= $quantity AND quantityto >= $quantity");  
   $query->execute();
   my $numberOfRows = $query->rows; 

   if ( $numberOfRows > 0 ) {
      my $ref = $query->fetchrow_hashref();
      my $rate = $ref->{'rate'};
      $query->finish();
      my $expectedAmount = $quantity * $rate;
      if ( $paymentAmount < $expectedAmount ) { 
	 return $enums::PURCHASE_UNDERPAID;
      }
      elsif ( $paymentAmount > $expectedAmount ) {
	 return $enums::PURCHASE_OVERPAID;
      }
      else {
	 return $enums::PURCHASE_OK;
      }
   }
   else {
   $query->finish();
      return $enums::PURCHASE_NOSUCHPRODUCT;
   }

}

sub insertPurchase
{
   my $purchase = shift;

   if ( !$purchase ) {
      print F "Invalid purchase passed to dbModule::insertPurchase\n";
      close F;
      return -1;
   }

   my $purchasedQuantity = $purchase->quantity;
   my $email = $purchase->email;
   my $jefecheckVersion = $purchase->version;
   my $status = $purchase->status;

   if ( $status == $enums::PURCHASE_OK ) {
$status = "ok";
   } elsif ( $status == $enums::PURCHASE_UNDERPAID ) {
      $status = "underpaid";
   } elsif ( $status == $enums::PURCHASE_OVERPAID ) {
      $status = "overpaid";
}
elsif ( $status == $enums::PURCHASE_NOSUCHPRODUCT ) {
      $status = "nosuchproduct";
}

   my $purchaseDate = localtime();
   #Generate the purchase confirmation number
   my $pcn = cryptModule::getRandomSequence($enums::PCN_SIZE, 4, "-");

   my $insert = "INSERT INTO $purchaseTable VALUES (0, '$purchaseDate',  $purchasedQuantity, 
   '$pcn', '$email', '$jefecheckVersion', '$status')";

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";
   $dbh->do($insert);
   my $purchaseID = $dbh->{'mysql_insertid'};
   $dbh->disconnect();

   return $purchaseID;
}

sub insertPayPalTransaction
{
   my $ppTransaction = shift;

   if ( !$ppTransaction ) {
      print F "Invalid purchase passed to dbModule::insertPayPalTransaction\n";
      close F;
      return -1;
   }
   my $txnid = $ppTransaction->txnID;
   my $amount = $ppTransaction->amount;
   my $quantity = $ppTransaction->quantity;
   my $pid = $ppTransaction->purchaseID;
   my $date = $ppTransaction->date;
   my $payerEmail = $ppTransaction->payerEmail;
   my $userEmail = $ppTransaction->userEmail;

   my $insert = "INSERT INTO $ppTable VALUES (0, '$txnid', '$amount', '$quantity', '$pid', '$date', '$payerEmail', '$userEmail')";

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";
   $dbh->do($insert);
   my $ppID = $dbh->{'mysql_insertid'};
   $dbh->disconnect();

   return $ppID;
}
sub getCost
{
   ( my $version, my $quantity ) = @_;

   if ( !$quantity or !$version ) {
      print F "Incorrect number of args passed to dbModule::getCost\n";
      close F;
      return -1;
   }

   my $dbh = connectToDB or die "Error: Could not estabilsh connection to DB!\n";

   my $query = $dbh->prepare("SELECT * FROM $rateTable WHERE jefecheckversion='$version' AND quantityfrom <= $quantity AND quantityto >= $quantity");  
   $query->execute();
   my $numberOfRows = $query->rows; 

   if ( $numberOfRows > 0 ) {
      my $ref = $query->fetchrow_hashref();
      $query->finish();
      return $ref->{'rate'} * $quantity;
   }
   else {
      $query->finish();
      return -1;
   }
}

sub insertDownload
{
 ( my $pcn, my $email, my $os ) = @_;

   if ( !$pcn or !$email or !$os ) {
      print F "Error: Incorrect number of args passed to dbModule::insertDownload\n";
      close F;
   }
   my $purchase = getPurchaseFromPCN($pcn);
   my $pid = $purchase->id;
   my $date = localtime();

   my $dbh = connectToDB or die "Error: Could not establish connection to DB!\n";

   my $insert = "INSERT INTO $downloadTable VALUES (0, '$pid',  '$date', '$os')";

   $dbh->do($insert);

   my $downloadID = $dbh->{'mysql_insertid'};
   $dbh->disconnect();

   return $downloadID;
}


1;